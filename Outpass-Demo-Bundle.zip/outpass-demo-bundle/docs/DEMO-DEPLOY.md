# Public demo - three ways to get a shareable link

The demo runs the program in "demo mode": fictional data only, one-click role login, Scan buttons on the gate page,
automatic reset every 30 minutes, a "Clear all data now" button, and dangerous actions switched off.

## ALWAYS: use only the Outpass-Demo-Bundle (it contains no real student data)
Never upload or run the demo from the full project folder: it contains `data/` with the real students.
**Demo mode erases its database. Always give it a SEPARATE EMPTY database.** (The program now refuses to start in demo mode if the
database contains real accounts, but do not rely on that - use a separate database.)

---------------------------------------------------------------------------------------------
## Option A - run it on your own PC and share a link (fastest, free, no account, works today)
The link works only while your PC is on and the program is running. The link changes every time you start the tunnel.

1. Create a separate empty database (pgAdmin or psql):
   `CREATE DATABASE outpass_demo OWNER outpass;`
2. Unzip `Outpass-Demo-Bundle.zip`, open a terminal in that folder and run (PowerShell):
   ```
   $env:DEMO_MODE="true"
   $env:SEED_TEST_ACCOUNTS="false"
   $env:DB_URL="jdbc:postgresql://localhost:5432/outpass_demo"
   mvn spring-boot:run
   ```
   Wait until the console says "PUBLIC DEMO MODE: fictional data loaded", then check http://localhost:8080
3. Install the free Cloudflare tunnel tool once: `winget install --id Cloudflare.cloudflared`
4. In a second terminal: `cloudflared tunnel --url http://localhost:8080`
   It prints a link like `https://something-random.trycloudflare.com`. **That is the link to share.** (HTTPS, works on phones.)
5. Stop sharing: press Ctrl+C in both terminals.

---------------------------------------------------------------------------------------------
## Option B - free cloud hosting: Render (program) + Neon (database)
Both have free plans without a card at the time of writing (plans change; check their pricing pages). The free web service sleeps
after ~15 minutes without visitors; the first visit afterwards takes 1-2 minutes to wake up. 512 MB memory is tight, so it can be slow.

1. Database: create a free project at https://neon.tech. Copy the **direct** (not "pooled") connection details:
   host, database, user, password.
2. Put the bundle in a public GitHub repository (create a free GitHub account -> New repository -> upload the unzipped files).
3. At https://render.com: New -> **Web Service** -> connect the repository -> Runtime **Docker**, **Dockerfile path: `./Dockerfile.render`**,
   Instance type **Free**.
4. Environment variables (Render -> Environment):
   * `DB_URL` = `jdbc:postgresql://HOST/DATABASE?sslmode=require`
   * `DB_USER` = your Neon user, `DB_PASSWORD` = your Neon password
   * `ADMIN_PASSWORD` = any long random text (nobody needs it)
   * `APP_BASE_URL` = the Render address of the service (e.g. https://outpass-demo.onrender.com)
5. Deploy. The first build takes about 10 minutes. The Render address is the link to share.

---------------------------------------------------------------------------------------------
## Option C - Hugging Face Spaces (only if your free CPU quota is available)
Create a Docker Space and upload the bundle (it already contains the right `Dockerfile` and `README.md`). If the Space shows
"Paused - CPU Basic quota reached", it cannot run until the quota resets or the account is upgraded.

---------------------------------------------------------------------------------------------
## Test script for any visitor (2 minutes)
1. Enter as **Student** -> New outpass request -> Submit.
2. Yellow bar -> **Switch role** -> **Tutor** -> open the request -> **Approve**.
3. Switch to **Student** -> open the request: QR with a live countdown.
4. Switch to **Security guard** -> press **Scan** next to the pass -> green VERIFIED.
5. Look around as HOD, Principal and Admin. Yellow bar -> **Clear all data now** resets everything.
